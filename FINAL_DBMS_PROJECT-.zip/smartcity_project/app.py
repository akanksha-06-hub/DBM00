
from flask import Flask, request, jsonify, render_template, redirect,session, url_for, flash
import random
from flask_cors import CORS
import mysql.connector
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


app.secret_key = "smartcity"  # for example, "smartcity123"
CORS(app)

# -------------------------------
# DATABASE CONNECTION
# -------------------------------
def get_db():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="Parawadi@123",
        database="smartcity"
    )
    return conn

@app.route("/forget_password")
def forget_password():
    num1 = random.randint(1,9)
    num2 = random.randint(1,9)

    session['captcha'] = num1 + num2

    return render_template("forget_password.html", num1=num1, num2=num2)

@app.route('/check_user', methods=['POST'])
def check_user():
    data = request.get_json()
    username = data['username']

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM citizen WHERE username=%s", (username,))
    user = cursor.fetchone()

    if user:
        return jsonify({"status":"ok"})
    else:
        return jsonify({"status":"error"})
    
@app.route('/verify_captcha', methods=['POST'])
def verify_captcha():
    data = request.get_json()
    user_ans = int(data['captcha'])

    if user_ans == session.get('captcha'):
        return jsonify({"status":"ok"})
    else:
        return jsonify({"status":"error"})
    
@app.route('/update_password', methods=['POST'])
def update_password():
    data = request.get_json()
    username = data['username']
    password = data['password']

    conn = get_db()
    cursor = conn.cursor()

    # Update citizen table
    cursor.execute(
        "UPDATE citizen SET password=%s WHERE username=%s",
        (password, username)
    )

    # Update admin table ALSO
    cursor.execute(
        "UPDATE admin SET password=%s WHERE username=%s",
        (password, username)
    )

    conn.commit()
    conn.close()

    return jsonify({"status":"ok"})
    

@app.route('/update_priority/<int:id>', methods=['POST'])
def update_priority(id):

    priority = request.form['priority']

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE complaint SET priority=%s WHERE complaint_id=%s",
        (priority, id)
    )

    conn.commit()
    conn.close()

    return redirect(url_for('admin_complaint'))

# -------------------------------
# FRONTEND ROUTES
# -------------------------------
@app.route('/admin_dashboard')
def admin_dashboard():

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # Total complaints
    cursor.execute("SELECT COUNT(*) AS total FROM complaint")
    total_complaints = cursor.fetchone()["total"]

    # Resolved complaints
    cursor.execute("SELECT COUNT(*) AS resolved FROM complaint WHERE status='Resolved'")
    resolved = cursor.fetchone()["resolved"]

    # ✅ Active Staff Count
    cursor.execute("SELECT COUNT(*) AS active_staff FROM staff WHERE availability_status='Active'")
    active_staff = cursor.fetchone()["active_staff"]

    # ✅ Total Feedback Count
    cursor.execute("SELECT COUNT(*) AS total_feedback FROM feedback")
    total_feedback = cursor.fetchone()["total_feedback"]

    # ✅ Latest 5 complaints
    cursor.execute("""
        SELECT complaint_type, description, status, date_submitted
        FROM complaint
        ORDER BY date_submitted DESC
        LIMIT 5
    """)
    complaints = cursor.fetchall()

    conn.close()

    return render_template(
        "admin_dashboard.html",
        total_complaints=total_complaints,
        resolved=resolved,
        active_staff=active_staff,
        total_feedback=total_feedback,
        complaints=complaints
    )
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/service")
def service():
    return render_template("service.html")


@app.route('/staff')
def staff():

    admin_id = session.get("admin_id")

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # ✅ Correct: find staff using admin_id
    cursor.execute("SELECT * FROM staff WHERE admin_id=%s", (admin_id,))
    staff = cursor.fetchone()
    

    if not staff:
     return "⚠️ No staff assigned to this admin. Contact superadmin."

    # ✅ Check if staff exists
    if not staff:
        return "No staff record found for this admin!"

    # ✅ Now safe to use staff_id
    cursor.execute(
        "SELECT * FROM complaint WHERE assigned_staff=%s",
        (staff['staff_id'],)
    )
    complaints = cursor.fetchall()

    conn.close()

    return render_template("staff.html", staff=staff, complaints=complaints)

@app.route('/add_staff', methods=['POST'])
def add_staff():

    admin_id = session.get("admin_id")  # 🔥 important

    name = request.form['name']
    designation = request.form['designation']
    availability_status = request.form['availability_status']

    conn = get_db()
    cursor = conn.cursor()

    query = """
    INSERT INTO staff (name, designation, availability_status, admin_id)
    VALUES (%s,%s,%s,%s)
    """

    cursor.execute(query,(name,designation,availability_status,admin_id))

    conn.commit()
    conn.close()

    return redirect('/admin_staff')


@app.route("/complaint")
def complaint():

    citizen_id = session.get("citizen_id")

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    cursor.execute(
        "SELECT * FROM complaint WHERE citizen_id=%s",
        (citizen_id,)
    )

    complaints = cursor.fetchall()

    return render_template("complaint.html", complaints=complaints)



@app.route("/citizen_register")
def citizen_register():
    return render_template("citizen_register.html")



@app.route("/citizen_login")
def citizen_login():
    return render_template("citizen_login.html")


@app.route("/feedback")
def feedback():

    citizen_id = session.get("citizen_id")

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    cursor.execute(
        "SELECT complaint_id, complaint_type, area_name FROM complaint WHERE citizen_id=%s",
        (citizen_id,)
    )

    complaints = cursor.fetchall()

    return render_template("feedback.html", complaints=complaints)



@app.route('/overall_feedback')
def overall_feedback():

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT f.feedback_id, f.rating, f.comment, f.date,
               c.name AS citizen_name,
               comp.complaint_type
        FROM feedback f
        JOIN citizen c ON f.citizen_id = c.citizen_id
        JOIN complaint comp ON f.complaint_id = comp.complaint_id
        ORDER BY f.date DESC
    """)

    feedbacks = cursor.fetchall()
    conn.close()

    return render_template("Overall_Feedback.html", feedbacks=feedbacks)

@app.route("/profile")
def profile():
    citizen_id = session.get("citizen_id")

    if not citizen_id:
        return redirect("/citizen_login")

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM citizen WHERE citizen_id=%s", (citizen_id,))
    user = cursor.fetchone()

    conn.close()

    return render_template("profile.html", user=user)


@app.route("/smartcity_dashboard")
def dashboard():

    citizen_id = session.get("citizen_id")

    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT name FROM citizen WHERE citizen_id=%s", (citizen_id,))
    user = cursor.fetchone()

    # Stats
    cursor.execute("SELECT COUNT(*) AS total FROM complaint")
    total_complaints = cursor.fetchone()["total"]

    cursor.execute("SELECT COUNT(*) AS resolved FROM complaint WHERE status='Resolved'")
    resolved = cursor.fetchone()["resolved"]

    cursor.execute("SELECT COUNT(*) AS active_staff FROM staff WHERE availability_status='Active'")
    active_staff = cursor.fetchone()["active_staff"]

    cursor.execute("SELECT COUNT(*) AS emergency FROM complaint WHERE priority='High'")
    emergency = cursor.fetchone()["emergency"]

    # ✅ My complaints count
    cursor.execute("""
        SELECT COUNT(*) AS my_count 
        FROM complaint 
        WHERE citizen_id=%s
    """, (citizen_id,))
    my_complaints = cursor.fetchone()["my_count"]

    # Latest complaints
    cursor.execute("""
        SELECT complaint_type, description, status, date_submitted
        FROM complaint
        WHERE citizen_id=%s
        ORDER BY date_submitted DESC
        LIMIT 5
    """, (citizen_id,))

    complaints = cursor.fetchall()

    conn.close()

    return render_template(
        "smartcity_dashboard.html",
        total_complaints=total_complaints,
        resolved=resolved,
        active_staff=active_staff,
        emergency=emergency,
        complaints=complaints,
        my_complaints=my_complaints,   # ✅ FIXED
        user=user
    )
@app.route("/citizen")
def citizen():
    
    return render_template("smartcity_dashboard.html")

@app.route("/submit_feedback", methods=["POST"])
def submit_feedback():

    citizen_id = session.get("citizen_id")

    if not citizen_id:
        return redirect("/citizen_login")

    complaint_id = request.form["complaint_id"]
    rating = request.form["rating"]
    comment = request.form["comment"]
    date = request.form["date"]

    conn = get_db()
    cursor = conn.cursor()

    query = """
    INSERT INTO feedback
    (citizen_id, complaint_id, rating, comment, date)
    VALUES (%s,%s,%s,%s,%s)
    """

    cursor.execute(query,(citizen_id, complaint_id, rating, comment, date))
    conn.commit()

    return redirect("/feedback")
    
    
@app.route('/admin_register', methods=['GET','POST'])
def admin_register():

    if request.method == 'POST':

        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO admin(name,email,phone,username,password,role)
        VALUES(%s,%s,%s,%s,%s,%s)
        """,(name,email,phone,username,password,role))

        admin_id = cursor.lastrowid  # ✅ INSIDE

        # auto-create staff if citymanager
        if role == "citymanager":
            cursor.execute("""
                INSERT INTO staff (admin_id, name, designation, availability_status)
                VALUES (%s, %s, %s, %s)
            """, (admin_id, name, None, "Active"))

        conn.commit()
        conn.close()

        return redirect(url_for('admin_login'))

    return render_template('admin_register.html')

@app.route("/api/register", methods=["POST"])
def register():
    conn = get_db()
    cursor = conn.cursor()

    name = request.form["name"]
    phone = request.form["phone"]
    email = request.form["email"]
    aadhar_no = request.form["aadhar_no"]
    age = request.form["age"]
    gender = request.form["gender"]
    address = request.form["address"]
    city = request.form["city"]
    pincode = request.form["pincode"]
    emergency = request.form["emergency_contact"]
    username = request.form["username"]
    password = request.form["password"]

    cursor.execute("""
    INSERT INTO citizen
    (name,phone,email,aadhar_no,age,gender,address,city,pincode,emergency_contact,username,password)
    VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """,(name,phone,email,aadhar_no,age,gender,address,city,pincode,emergency,username,password))
    conn.commit()
    # Get the newly created citizen_id
    citizen_id = cursor.lastrowid

# Store in session
    session["citizen_id"] = citizen_id
    session["username"] = username
    conn.commit()
    return redirect("/citizen_login")
# -------------------------------
# LOGIN API
# -------------------------------
@app.route("/api/login", methods=["POST"])
def citizen_login_api():

    login_id = request.form["login_id"]
    password = request.form["password"]

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    query = """
    SELECT * FROM citizen
    WHERE (username=%s OR email=%s OR phone=%s) AND password=%s
    """

    cursor.execute(query, (login_id, login_id, login_id, password))

    citizen = cursor.fetchone()

    if citizen:

        session["citizen_id"] = citizen["citizen_id"]
        session["username"] = citizen["username"]

        return redirect(url_for("dashboard"))

    else:
        return "Invalid Login"

# -------------------------------
# CREATE COMPLAINT
# -------------------------------
@app.route('/admin_login', methods=['GET','POST'])
def admin_login():

    if request.method == 'POST':

        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        conn = get_db()
        cursor = conn.cursor(dictionary=True)

        query = """
        SELECT * FROM admin
        WHERE username=%s AND password=%s AND role=%s
        """

        cursor.execute(query,(username,password,role))

        admin = cursor.fetchone()

        if admin:

            session['admin_id'] = admin['admin_id']
            session['role'] = admin['role']

            if admin['role'] == "superadmin":
                return redirect(url_for('admin_dashboard'))

            elif admin['role'] == "citymanager":
                return redirect(url_for('staff_dashboard'))

        else:
            return "Invalid Login"

    return render_template("admin_login.html")
# -------------------------------
# GET ALL COMPLAINTS
# -------------------------------
@app.route("/submit_complaint", methods=["POST"])
def submit_complaint():

    citizen_id = session.get("citizen_id")

    if not citizen_id:
        return redirect("/citizen_login")

    complaint_type = request.form.get("complaint_type")
    description = request.form.get("description")
    priority = request.form.get("priority")
    date = request.form.get("date")
    area_name = request.form.get("area_name")
    landmark = request.form.get("landmark")
    gps = request.form.get("gps")
    ward_no = request.form.get("ward_no")

    

    conn = get_db()
    cursor = conn.cursor()

    query = """
    INSERT INTO complaint 
    (citizen_id, complaint_type, description, priority, date_submitted, area_name, landmark, gps, ward_no, status)
    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,'Pending')
    """

    cursor.execute(query, (
        citizen_id, complaint_type, description, priority, date,
        area_name, landmark, gps, ward_no
    ))

    conn.commit()

    return redirect("/complaint")
    
# -------------------------------
# ASSIGN STAFF
# -------------------------------
@app.route('/update_staff_status/<int:id>', methods=['POST'])
def update_staff_status(id):

    status = request.form['status']
    designation = request.form.get('designation')

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT designation FROM staff WHERE staff_id=%s", (id,))
    staff = cursor.fetchone()

    # ✅ ONLY set designation if it's empty in DB
    if not staff['designation']:   # better check
        if designation:  # user selected something
            cursor.execute(
                "UPDATE staff SET designation=%s, availability_status=%s WHERE staff_id=%s",
                (designation, status, id)
            )
    else:
        cursor.execute(
            "UPDATE staff SET availability_status=%s WHERE staff_id=%s",
            (status, id)
        )

    conn.commit()
    conn.close()

    return redirect('/staff')
# -------------------------------
# ADD LOCATION
# -------------------------------

@app.route("/api/location", methods=["POST"])
def add_location():

    
    data = request.form

    area = data["area_name"]
    landmark = data["landmark"]
    gps = data["gps"]
    ward = data["ward_no"]

    conn = get_db()
    cursor = conn.cursor()

    query = """
    INSERT INTO location(area_name,landmark,gps_coordinates,ward_no)
    VALUES(%s,%s,%s,%s)
    """

    cursor.execute(query,(area,landmark,gps,ward))
    conn.commit()

    return jsonify({"message":"Location added"})



@app.route('/admin_complaint')
def admin_complaint():

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # complaints
    
    cursor.execute("""
SELECT * FROM complaint
ORDER BY date_submitted DESC
""")
    complaints = cursor.fetchall()

    # feedback
    
    cursor.execute("""
SELECT * FROM feedback
ORDER BY date DESC
""")
    feedbacks = cursor.fetchall()

    # active staff only
    cursor.execute("""
    SELECT staff_id,name,designation
    FROM staff
    WHERE availability_status='Active'
    """)
    staff = cursor.fetchall()

    conn.close()

    return render_template(
        "admin_complaint.html",
        complaints=complaints,
        feedbacks=feedbacks,
        staff=staff
    )

@app.route('/update_status/<int:id>', methods=['POST'])
def update_status(id):

    status = request.form['status']

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE complaint SET status=%s WHERE complaint_id=%s",
        (status, id)
    )

    conn.commit()
    conn.close()

    return redirect(url_for('admin_complaint'))
    
    
@app.route('/assign_staff/<int:id>', methods=['POST'])
def assign_staff(id):

    staff_id = request.form['staff_id']

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE complaint SET assigned_staff=%s WHERE complaint_id=%s",
        (staff_id, id)
    )

    conn.commit()
    conn.close()

    return redirect(url_for('admin_complaint'))
   
@app.route('/admin_staff')
def admin_staff():

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # Latest Active Staff
    cursor.execute("""
        SELECT * FROM staff
        WHERE availability_status='Active'
        AND staff_id IN (
            SELECT MAX(staff_id)
            FROM staff
            GROUP BY name
        )
    """)
    active_staff = cursor.fetchall()

    # Latest Inactive Staff
    cursor.execute("""
        SELECT * FROM staff
        WHERE availability_status='Inactive'
        AND staff_id IN (
            SELECT MAX(staff_id)
            FROM staff
            GROUP BY name
        )
    """)
    inactive_staff = cursor.fetchall()

    conn.close()

    return render_template(
        "admin_staff.html",
        active_staff=active_staff,
        inactive_staff=inactive_staff
    )
# -------------------------------
# ADD FEEDBACK
# -------------------------------

#@app.route("/api/feedback", methods=["POST"])
#def feedback():

    data = request.form
    citizen_id = data["citizen_id"]
    comment = data["comment"]
    rating = data["rating"]

    conn = get_db()
    cursor = conn.cursor()

    query = """
   # INSERT INTO feedback(citizen_id,comments,rating)
   # VALUES(%s,%s,%s)
    """

    cursor.execute(query,(citizen_id,comment,rating))
    conn.commit()

    return jsonify({"message":"Feedback submitted"})

@app.route('/staff_dashboard')
def staff_dashboard():

    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect("/admin_login")

    # ✅ FIRST create connection
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # ✅ Get admin data

    cursor.execute("SELECT * FROM staff WHERE admin_id=%s", (admin_id,))
    staff = cursor.fetchone()

    # ✅ Get complaints (assigned to admin)
    cursor.execute("""
        SELECT * FROM complaint 
        WHERE assigned_staff=%s
    """, (staff['staff_id'],))
    
    complaints = cursor.fetchall()

    conn.close()

    return render_template("staff.html", staff=staff, complaints=complaints)


@app.route("/update_profile", methods=["POST"])
def update_profile():
    citizen_id = session.get("citizen_id")

    if not citizen_id:
        return redirect("/citizen_login")
    
    username = request.form["username"]
    name = request.form["name"]
    phone = request.form["phone"]
    address = request.form["address"]
    city = request.form["city"]
    pincode = request.form["pincode"]
    

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE citizen
        SET username=%s, name=%s, phone=%s, address=%s, city=%s, pincode=%s
        WHERE citizen_id=%s
    """, (username,name, phone, address, city, pincode, citizen_id))

    conn.commit()
    conn.close()

    session["username"] = username
    flash("Profile updated successfully!")

    return redirect("/profile")
# -------------------------------
# START SERVER
# -------------------------------

@app.route("/test_db")
def test_db():

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SHOW TABLES")

    tables = cursor.fetchall()

    return str(tables)

@app.route("/admin_profile")
def admin_profile():
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect("/admin_login")

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM admin WHERE admin_id=%s", (admin_id,))
    user = cursor.fetchone()

    conn.close()

    return render_template("admin_profile.html", user=user)


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/admin_login")


@app.route("/update_admin_profile", methods=["POST"])
def update_admin_profile():
    admin_id = session.get("admin_id")

    if not admin_id:
        return redirect("/admin_login")

    username = request.form["username"]
    name = request.form["name"]
    phone = request.form["phone"]
    email = request.form["email"]

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE admin
        SET username=%s, name=%s, phone=%s ,email=%s
        WHERE admin_id=%s
    """, (username, name, phone, email, admin_id))

    conn.commit()
    conn.close()

    session["username"] = username

    flash("Admin profile updated successfully!")

    return redirect("/admin_profile")


# ✅ ALWAYS LAST
if __name__ == "__main__":
    app.run(debug=True)

